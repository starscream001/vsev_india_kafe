# AI Defect Interviewer

Локальный MVP для подготовки качественного описания дефекта через GigaCode CLI.

## Быстрый запуск

```bash
chmod +x run.sh
./run.sh
```

Страница откроется автоматически. Если нет — откройте вручную:

```text
http://127.0.0.1:8000
```

## Ярлык на рабочий стол

```bash
chmod +x create_desktop_shortcut.sh
./create_desktop_shortcut.sh
```

После этого запускайте `AI Defect Interviewer` с рабочего стола двойным кликом.

## Проверка GigaCode CLI

```bash
gigacode "Ответь одним словом TEST"
```

## Если ничего не происходит

Откройте файл лога:

```bash
cat ai-defect-interviewer.log
```

## Остановка сервера

```bash
./stop.sh
```
