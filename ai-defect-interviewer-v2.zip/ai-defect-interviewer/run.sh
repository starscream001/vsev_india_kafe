#!/bin/bash
set -u
cd "$(dirname "$0")"

LOG_FILE="$(pwd)/ai-defect-interviewer.log"
URL="http://127.0.0.1:8000"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "Старт AI Defect Interviewer"

if ! command -v python3 >/dev/null 2>&1; then
  log "ОШИБКА: Python3 не найден. Установите python3."
  read -p "Нажмите Enter для выхода..."
  exit 1
fi

if ! command -v gigacode >/dev/null 2>&1; then
  log "ОШИБКА: GigaCode CLI не найден в PATH. Проверьте: gigacode \"Ответь TEST\""
  read -p "Нажмите Enter для выхода..."
  exit 1
fi

if ! python3 -m venv --help >/dev/null 2>&1; then
  log "ОШИБКА: python3-venv не установлен. Установите: sudo apt install python3-venv"
  read -p "Нажмите Enter для выхода..."
  exit 1
fi

if [ ! -d ".venv" ]; then
  log "Создаю виртуальное окружение..."
  python3 -m venv .venv >> "$LOG_FILE" 2>&1
fi

source .venv/bin/activate

log "Устанавливаю зависимости..."
pip install -r requirements.txt >> "$LOG_FILE" 2>&1

# Если сервер уже запущен — просто открыть страницу
if command -v curl >/dev/null 2>&1 && curl -s "$URL" >/dev/null 2>&1; then
  log "Сервер уже запущен. Открываю браузер: $URL"
  xdg-open "$URL" >/dev/null 2>&1 || true
  exit 0
fi

log "Запускаю сервер..."
nohup python3 app.py >> "$LOG_FILE" 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" > .server.pid

# Ждём старта сервера до 15 секунд
for i in {1..15}; do
  if command -v curl >/dev/null 2>&1; then
    if curl -s "$URL" >/dev/null 2>&1; then
      log "Сервер запущен. Открываю браузер: $URL"
      xdg-open "$URL" >/dev/null 2>&1 || true
      log "Готово. Если браузер не открылся, откройте вручную: $URL"
      exit 0
    fi
  else
    sleep 3
    xdg-open "$URL" >/dev/null 2>&1 || true
    log "Если браузер не открылся, откройте вручную: $URL"
    exit 0
  fi
  sleep 1
done

log "ОШИБКА: сервер не стартовал. Смотрите лог: $LOG_FILE"
read -p "Нажмите Enter для выхода..."
exit 1
