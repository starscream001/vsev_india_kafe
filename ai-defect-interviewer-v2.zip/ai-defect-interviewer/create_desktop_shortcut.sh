#!/bin/bash
set -e
cd "$(dirname "$0")"
APP_DIR="$(pwd)"
DESKTOP_DIR="$HOME/Desktop"
[ -d "$DESKTOP_DIR" ] || DESKTOP_DIR="$HOME/Рабочий стол"
mkdir -p "$DESKTOP_DIR"
SHORTCUT="$DESKTOP_DIR/AI Defect Interviewer.desktop"
cat > "$SHORTCUT" <<EOL
[Desktop Entry]
Type=Application
Name=AI Defect Interviewer
Comment=Запуск локального AI-интервьюера дефектов
Exec=$APP_DIR/run.sh
Path=$APP_DIR
Terminal=true
Icon=utilities-terminal
Categories=Development;
EOL
chmod +x "$SHORTCUT"
echo "Ярлык создан: $SHORTCUT"
