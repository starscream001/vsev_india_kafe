#!/bin/bash
cd "$(dirname "$0")"
if [ -f .server.pid ]; then
  kill "$(cat .server.pid)" 2>/dev/null || true
  rm -f .server.pid
  echo "Сервер остановлен"
else
  echo "PID-файл не найден. Если нужно, остановите процесс вручную: pkill -f 'python3 app.py'"
fi
