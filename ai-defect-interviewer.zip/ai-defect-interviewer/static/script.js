const $ = (id) => document.getElementById(id);

function setLoading(button, loadingText) {
  const oldText = button.textContent;
  button.disabled = true;
  button.textContent = loadingText;
  return () => {
    button.disabled = false;
    button.textContent = oldText;
  };
}

async function postJson(url, payload) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.detail || "Ошибка запроса");
  }
  return data;
}

$("fillDemoBtn").addEventListener("click", () => {
  $("rawDefect").value = "После удаления диалога он остаётся в списке диалогов.";
  $("defectType").value = "Frontend";
  $("environment").value = "IFT";
  $("steps").value = "1. Открыть список диалогов\n2. Выбрать диалог\n3. Выполнить удаление диалога\n4. Обновить список диалогов";
  $("expectedResult").value = "Удалённый диалог не отображается в списке диалогов.";
  $("actualResult").value = "Удалённый диалог продолжает отображаться в списке диалогов.";
  $("artifactComment").value = "Скриншот будет приложен в Jira.";
  $("reproducibility").value = "Всегда";
  $("additionalInfo").value = "Пользователь авторизован. Значение isHidden = true.";
});

$("interviewBtn").addEventListener("click", async () => {
  const rawDefect = $("rawDefect").value.trim();
  const stopLoading = setLoading($("interviewBtn"), "GigaCode думает...");
  $("interviewResult").classList.remove("muted");
  $("interviewResult").textContent = "Выполняется запрос в GigaCode CLI...";

  try {
    const data = await postJson("/api/interview", { raw_defect: rawDefect });
    $("interviewResult").textContent = data.result;
  } catch (error) {
    $("interviewResult").textContent = "Ошибка: " + error.message;
  } finally {
    stopLoading();
  }
});

$("finalizeBtn").addEventListener("click", async () => {
  const checkedArtifacts = Array.from(document.querySelectorAll(".checks input:checked"))
    .map((item) => item.value);

  const payload = {
    raw_defect: $("rawDefect").value.trim(),
    defect_type: $("defectType").value,
    environment: $("environment").value.trim(),
    steps: $("steps").value.trim(),
    expected_result: $("expectedResult").value.trim(),
    actual_result: $("actualResult").value.trim(),
    artifacts: checkedArtifacts,
    artifact_comment: $("artifactComment").value.trim(),
    reproducibility: $("reproducibility").value.trim(),
    additional_info: $("additionalInfo").value.trim(),
  };

  const stopLoading = setLoading($("finalizeBtn"), "Формирую дефект...");
  $("finalResult").classList.remove("muted");
  $("finalResult").textContent = "Выполняется запрос в GigaCode CLI...";

  try {
    const data = await postJson("/api/finalize", payload);
    $("finalResult").textContent = data.result;
  } catch (error) {
    $("finalResult").textContent = "Ошибка: " + error.message;
  } finally {
    stopLoading();
  }
});

$("copyBtn").addEventListener("click", async () => {
  const text = $("finalResult").textContent;
  await navigator.clipboard.writeText(text);
  const old = $("copyBtn").textContent;
  $("copyBtn").textContent = "Скопировано";
  setTimeout(() => $("copyBtn").textContent = old, 1200);
});
