import subprocess
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from starlette.requests import Request
import uvicorn

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(title="AI Defect Interviewer")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


class InterviewRequest(BaseModel):
    raw_defect: str


class FinalDefectRequest(BaseModel):
    raw_defect: str
    defect_type: Optional[str] = None
    environment: Optional[str] = None
    steps: Optional[str] = None
    expected_result: Optional[str] = None
    actual_result: Optional[str] = None
    artifacts: Optional[List[str]] = []
    artifact_comment: Optional[str] = None
    reproducibility: Optional[str] = None
    additional_info: Optional[str] = None


def run_gigacode(prompt: str, timeout: int = 180) -> str:
    """Запускает GigaCode CLI в one-shot режиме."""
    try:
        result = subprocess.run(
            ["gigacode", prompt],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError:
        raise HTTPException(status_code=500, detail="Команда gigacode не найдена в PATH")
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="GigaCode CLI не ответил за отведённое время")

    output = (result.stdout or "").strip()
    error = (result.stderr or "").strip()

    if result.returncode != 0:
        raise HTTPException(
            status_code=500,
            detail=f"Ошибка GigaCode CLI: {error or output or 'неизвестная ошибка'}",
        )

    return output or error or "Пустой ответ от GigaCode CLI"


def build_interview_prompt(raw_defect: str) -> str:
    return f"""
Ты AI Defect Interviewer для QA-команды Сбербанка.
Работай в закрытом контуре. Не используй внешние источники.

Задача: проанализировать черновик дефекта и задать недостающие уточняющие вопросы.
Не переписывай дефект полностью на этом шаге.

Черновик дефекта:
{raw_defect}

Проверь, хватает ли информации по блокам:
1. Тип дефекта: frontend или backend.
2. Окружение / стенд.
3. Шаги воспроизведения.
4. Ожидаемый результат.
5. Фактический результат.
6. Артефакты.
   - Для frontend желательно: скриншот или ссылка на макет.
   - Для backend желательно: логи, текст ошибки, requestId/traceId, стенд.
7. Воспроизводимость.

Верни ответ строго в формате:
1. Краткая оценка полноты: ...
2. Недостающая информация: ...
3. Вопросы тестировщику:
   1) ...
   2) ...
   3) ...

Задай не больше 7 вопросов. Пиши кратко и по делу.
""".strip()


def build_final_prompt(data: FinalDefectRequest) -> str:
    artifacts = ", ".join(data.artifacts or []) or "Не указаны"
    return f"""
Ты Senior QA Lead.
На основе исходного описания и ответов тестировщика сформируй качественное описание дефекта для вставки в Jira.

ВАЖНО:
- Не выдумывай факты.
- Если данных нет, напиши: "Не указано".
- Артефакты не надо анализировать, только указать, что их нужно приложить в Jira.
- Стиль: технический, краткий, понятный разработчику.

Исходный дефект:
{data.raw_defect}

Ответы тестировщика:
Тип дефекта: {data.defect_type or 'Не указано'}
Окружение / стенд: {data.environment or 'Не указано'}
Шаги: {data.steps or 'Не указано'}
Ожидаемый результат: {data.expected_result or 'Не указано'}
Фактический результат: {data.actual_result or 'Не указано'}
Артефакты: {artifacts}
Комментарий по артефактам: {data.artifact_comment or 'Не указано'}
Воспроизводимость: {data.reproducibility or 'Не указано'}
Дополнительная информация: {data.additional_info or 'Не указано'}

Сформируй результат строго по шаблону:

Заголовок:
...

Тип дефекта:
...

Окружение / стенд:
...

Предусловия:
...

Шаги воспроизведения:
1. ...
2. ...
3. ...

Ожидаемый результат:
...

Фактический результат:
...

Воспроизводимость:
...

Артефакты:
- ...

Дополнительная информация:
...

Что рекомендуется приложить в Jira:
- ...

Defect Quality Score: N/100

Что ещё желательно уточнить:
- ...
""".strip()


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/api/interview")
def interview(payload: InterviewRequest):
    if not payload.raw_defect.strip():
        raise HTTPException(status_code=400, detail="Введите описание дефекта")
    prompt = build_interview_prompt(payload.raw_defect.strip())
    return {"result": run_gigacode(prompt)}


@app.post("/api/finalize")
def finalize(payload: FinalDefectRequest):
    if not payload.raw_defect.strip():
        raise HTTPException(status_code=400, detail="Введите описание дефекта")
    prompt = build_final_prompt(payload)
    return {"result": run_gigacode(prompt)}


if __name__ == "__main__":
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=False)
