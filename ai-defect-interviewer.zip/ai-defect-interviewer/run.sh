#!/bin/bash
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python3 не найден. Установите python3."
  read -p "Нажмите Enter для выхода..."
  exit 1
fi

if ! command -v gigacode >/dev/null 2>&1; then
  echo "GigaCode CLI не найден в PATH. Проверьте команду: gigacode \"Ответь TEST\""
  read -p "Нажмите Enter для выхода..."
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "Создаю виртуальное окружение..."
  python3 -m venv .venv
fi

source .venv/bin/activate

echo "Устанавливаю зависимости..."
pip install -r requirements.txt

echo "Запускаю AI Defect Interviewer..."
echo "Откройте в браузере: http://127.0.0.1:8000"
python3 app.py
