#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
import subprocess
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

HOST = "127.0.0.1"
PORT = 8000
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INDEX_FILE = os.path.join(BASE_DIR, "index.html")


def build_prompt(data: dict) -> str:
    return f"""
Ты Senior QA Lead в банковской IT-команде.

Нужно сформировать качественное описание дефекта для Jira на русском языке.
Не выдумывай факты. Если данных не хватает — укажи это в блоке "Что желательно добавить".

Исходные данные:

Краткое описание проблемы:
{data.get('summary', '').strip()}

Тип дефекта: {data.get('defect_type', '').strip()}
Стенд / окружение: {data.get('environment', '').strip()}
Шаги от пользователя: {data.get('steps', '').strip()}
Ожидаемый результат: {data.get('expected', '').strip()}
Фактический результат: {data.get('actual', '').strip()}
Артефакты: {data.get('artifacts', '').strip()}
Воспроизводимость: {data.get('reproducibility', '').strip()}
Дополнительная информация: {data.get('extra', '').strip()}

Сформируй ответ строго в таком формате:

Заголовок:

Окружение:

Предусловия:

Шаги воспроизведения:
1.
2.
3.

Ожидаемый результат:

Фактический результат:

Артефакты:

Воспроизводимость:

Что желательно добавить:

Defect Quality Score:
число от 0 до 100 и краткое пояснение.
""".strip()


def call_gigacode(prompt: str) -> str:
    try:
        result = subprocess.run(
            ["gigacode", prompt],
            capture_output=True,
            text=True,
            timeout=180,
        )
    except FileNotFoundError:
        return "ОШИБКА: команда gigacode не найдена. Проверьте, что GigaCode CLI запускается из этого же терминала командой: gigacode \"TEST\""
    except subprocess.TimeoutExpired:
        return "ОШИБКА: GigaCode CLI не ответил за 180 секунд. Попробуйте сократить описание дефекта или проверить доступность CLI."

    output = (result.stdout or "").strip()
    error = (result.stderr or "").strip()

    if result.returncode != 0:
        return f"ОШИБКА GigaCode CLI. Код: {result.returncode}\n\nSTDOUT:\n{output}\n\nSTDERR:\n{error}"

    return output or error or "GigaCode CLI вернул пустой ответ."


class Handler(BaseHTTPRequestHandler):
    def _send(self, status: int, body: bytes, content_type: str):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            with open(INDEX_FILE, "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        else:
            self._send(404, b"Not found", "text/plain; charset=utf-8")

    def do_POST(self):
        path = urlparse(self.path).path
        if path != "/generate":
            self._send(404, b"Not found", "text/plain; charset=utf-8")
            return

        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length).decode("utf-8")

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            self._send(400, "Некорректный JSON".encode("utf-8"), "text/plain; charset=utf-8")
            return

        prompt = build_prompt(data)
        answer = call_gigacode(prompt)
        response = json.dumps({"answer": answer, "prompt": prompt}, ensure_ascii=False).encode("utf-8")
        self._send(200, response, "application/json; charset=utf-8")

    def log_message(self, format, *args):
        return


if __name__ == "__main__":
    print("AI Defect Interviewer запущен")
    print(f"Откройте в браузере: http://{HOST}:{PORT}")
    try:
        webbrowser.open(f"http://{HOST}:{PORT}")
    except Exception:
        pass
    HTTPServer((HOST, PORT), Handler).serve_forever()
