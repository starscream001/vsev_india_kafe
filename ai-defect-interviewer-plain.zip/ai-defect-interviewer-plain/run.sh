#!/bin/bash
cd "$(dirname "$0")"
echo "Запуск AI Defect Interviewer..."
echo "Если браузер не открылся, откройте вручную: http://127.0.0.1:8000"
python3 app.py
