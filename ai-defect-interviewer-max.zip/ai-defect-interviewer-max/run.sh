#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "AI Defect Reviewer & Investigator"
echo "Проверяю python3..."
python3 --version

echo "Проверяю gigacode..."
if ! command -v gigacode >/dev/null 2>&1; then
  echo "ОШИБКА: gigacode не найден в PATH"
  echo "Проверь: which gigacode"
  exit 1
fi

echo "Запускаю локальный сервер..."
echo "Если браузер не открылся, открой вручную: http://127.0.0.1:8000/index.html"
python3 app.py
