# AI Defect Reviewer & Investigator

MVP без зависимостей: только стандартный Python 3 + `gigacode` CLI.

## Запуск

```bash
bash run.sh
```

Если браузер не открылся:

```text
http://127.0.0.1:8000/index.html
```

## Что делает

1. Анализирует сырой дефект и задаёт вопросы.
2. Формирует Jira-ready дефект.
3. Проводит AI Review / Quality Gate.
4. Выдаёт Quality Score, риски, рекомендации и список недостающих артефактов.

## Если GigaCode долго отвечает

Можно увеличить таймаут:

```bash
GIGACODE_TIMEOUT=400 bash run.sh
```

## Если команда gigacode называется иначе

```bash
GIGACODE_BIN=/path/to/gigacode bash run.sh
```
