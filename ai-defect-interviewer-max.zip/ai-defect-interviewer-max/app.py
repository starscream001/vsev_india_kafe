#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AI Defect Reviewer & Investigator
Запуск: python3 app.py
Зависимости: только стандартный Python + установленный gigacode CLI
"""

import json
import os
import subprocess
import sys
import time
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

BASE_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = int(os.environ.get("DEFECT_AI_PORT", "8000"))
GIGACODE_BIN = os.environ.get("GIGACODE_BIN", "gigacode")
TIMEOUT_SECONDS = int(os.environ.get("GIGACODE_TIMEOUT", "240"))


def run_gigacode(prompt: str) -> str:
    """Вызывает GigaCode CLI в one-shot режиме."""
    try:
        completed = subprocess.run(
            [GIGACODE_BIN, prompt],
            capture_output=True,
            text=True,
            timeout=TIMEOUT_SECONDS,
        )
    except FileNotFoundError:
        return (
            "ОШИБКА: команда gigacode не найдена.\n\n"
            "Проверь в терминале:\n"
            "which gigacode\n\n"
            "Если команда называется иначе, запусти так:\n"
            "GIGACODE_BIN=/путь/к/gigacode python3 app.py"
        )
    except subprocess.TimeoutExpired:
        return f"ОШИБКА: GigaCode не ответил за {TIMEOUT_SECONDS} сек. Попробуй сократить ввод или увеличить GIGACODE_TIMEOUT."

    stdout = (completed.stdout or "").strip()
    stderr = (completed.stderr or "").strip()

    if completed.returncode != 0:
        return (
            f"ОШИБКА ВЫЗОВА GigaCode. Код: {completed.returncode}\n\n"
            f"STDERR:\n{stderr}\n\nSTDOUT:\n{stdout}"
        ).strip()

    return stdout if stdout else stderr


def build_analyze_prompt(initial_description: str) -> str:
    return f"""
Ты Senior QA Lead и AI Defect Interviewer в корпоративной QA-команде.

Твоя задача — проанализировать сырой черновик дефекта и задать точные вопросы, чтобы тестировщик смог быстро собрать качественный defect report для Jira.

Не оформляй дефект полностью на этом шаге.
Не хвали автора.
Не пиши общие слова.
Не выдумывай факты.

Исходное описание дефекта:
{initial_description}

Проанализируй, какой информации не хватает для качественного дефекта.
Проверь:
- frontend это или backend;
- стенд / окружение;
- предусловия;
- шаги воспроизведения;
- ожидаемый результат;
- фактический результат;
- воспроизводимость;
- артефакты;
- влияние на пользователя;
- для frontend: скриншот, видео, ссылка на макет, ошибка в консоли;
- для backend: requestId, traceId, логи, текст ошибки, сервис, стенд.

Верни ответ строго в таком формате:

КРАТКИЙ АНАЛИЗ:
[2-4 предложения: что понятно из описания и чего критично не хватает]

ВОПРОСЫ ДЛЯ ИНТЕРВЬЮ:
1. [самый важный вопрос]
2. [вопрос]
3. [вопрос]
4. [вопрос]
5. [вопрос]
6. [вопрос]
7. [вопрос]

ПРЕДВАРИТЕЛЬНЫЕ РИСКИ:
- [риск]
- [риск]
- [риск]
""".strip()


def build_generate_prompt(data: dict) -> str:
    return f"""
Ты Senior QA Lead, Senior Developer Reviewer и Production Support Engineer.

Твоя задача — на основе исходного описания и ответов тестировщика сформировать качественный defect report для Jira.

ВАЖНЫЕ ПРАВИЛА:
- Не выдумывай данные.
- Если информации нет, пиши: "не указано".
- Формулируй технически, кратко и пригодно для Jira.
- Не добавляй воду, похвалу и объяснения процесса.
- Сделай так, чтобы разработчик смог воспроизвести дефект без дополнительных вопросов.
- Если шаги описаны неструктурно, разложи их на понятные шаги.
- Если видишь слабое место — вынеси в рекомендации, но не подменяй фактами.

ИСХОДНОЕ ОПИСАНИЕ:
{data.get('initial_description', '')}

ОТВЕТЫ ИНТЕРВЬЮ:
Тип дефекта / область: {data.get('defect_type', '')}
Компонент / раздел: {data.get('component', '')}
Окружение / стенд: {data.get('environment', '')}
Роль пользователя / тестовые данные: {data.get('user_role', '')}
Предусловия: {data.get('preconditions', '')}
Шаги воспроизведения: {data.get('steps', '')}
Ожидаемый результат: {data.get('expected_result', '')}
Фактический результат: {data.get('actual_result', '')}
Воспроизводимость: {data.get('reproducibility', '')}
Артефакты: {data.get('artifacts', '')}
Текст ошибки / requestId / traceId / логи: {data.get('technical_details', '')}
Влияние на пользователя: {data.get('impact', '')}
Дополнительный контекст: {data.get('extra_context', '')}

СФОРМИРУЙ ГОТОВЫЙ ДЕФЕКТ СТРОГО В ТАКОЙ СТРУКТУРЕ:

Заголовок:
[короткий заголовок: где + что сломано + при каком действии]

Предусловия:
[условия, роль, тестовые данные, состояние системы]

Шаги воспроизведения:
1.
2.
3.

Ожидаемый результат:
[что должно происходить]

Фактический результат:
[что происходит сейчас]

Окружение:
[стенд, версия, браузер/приложение, платформа, если указано]

Артефакты:
[что приложено или должно быть приложено]

Воспроизводимость:
[всегда / иногда / не указано]

Влияние на пользователя:
[какой пользовательский или бизнес-сценарий страдает]

Дополнительная информация для разработки:
[requestId, traceId, сервисы, текст ошибки, гипотезы только если они явно следуют из данных]

Что ещё желательно приложить:
- Для frontend: скриншот, видео, ссылка на макет, ошибки консоли браузера
- Для backend: логи, requestId/traceId, текст ошибки, стенд, сервис/метод
""".strip()


def build_review_prompt(data: dict, generated_defect: str) -> str:
    return f"""
Ты Senior QA Lead, Senior Developer и Production Support Engineer.

Твоя задача — провести жесткое ревью качества дефекта перед передачей в разработку.

Не переписывай дефект заново.
Не хвали автора.
Не используй общие фразы.
Критикуй объективно.
Если данных не хватает — прямо укажи, каких именно и зачем они нужны.

ИСХОДНОЕ ОПИСАНИЕ:
{data.get('initial_description', '')}

СФОРМИРОВАННЫЙ ДЕФЕКТ:
{generated_defect}

Проверь дефект по критериям:
1. Можно ли воспроизвести дефект по шагам.
2. Понятен ли ожидаемый результат.
3. Конкретен ли фактический результат.
4. Достаточно ли окружения.
5. Достаточно ли артефактов.
6. Есть ли данные для frontend/backend анализа.
7. Понятно ли влияние на пользователя.
8. Сможет ли новый разработчик без контекста взять дефект в работу.

Оцени по шкале 0-100:
- Шаги воспроизведения — 20 баллов
- Ожидаемый результат — 15 баллов
- Фактический результат — 15 баллов
- Окружение — 15 баллов
- Артефакты — 15 баллов
- Воспроизводимость — 10 баллов
- Полезность для разработчика — 10 баллов

Верни результат строго в такой структуре:

Defect Quality Score:
XX/100

Готовность к передаче в разработку:
ДА / НЕТ / УСЛОВНО

Вердикт QA Lead:
[короткий жесткий вывод: можно заводить или надо доработать]

Проверка полноты:
- Шаги воспроизведения: OK / Не хватает — [комментарий]
- Ожидаемый результат: OK / Не хватает — [комментарий]
- Фактический результат: OK / Не хватает — [комментарий]
- Окружение: OK / Не хватает — [комментарий]
- Артефакты: OK / Не хватает — [комментарий]
- Воспроизводимость: OK / Не хватает — [комментарий]
- Данные для разработки: OK / Не хватает — [комментарий]

Что вероятно запросит разработчик:
1.
2.
3.

Что ещё нужно приложить:
1.
2.
3.

Вероятные направления анализа:
1. [техническая гипотеза, если логично следует из дефекта]
2. [техническая гипотеза]
3. [техническая гипотеза]

Риски:
1.
2.
3.

Рекомендации по улучшению:
1.
2.
3.
""".strip()


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE_DIR), **kwargs)

    def log_message(self, fmt, *args):
        print(f"[{time.strftime('%H:%M:%S')}] " + fmt % args)

    def _send_json(self, payload: dict, status: int = 200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length).decode("utf-8") if length else "{}"
        return json.loads(raw or "{}")

    def do_POST(self):
        try:
            path = urlparse(self.path).path
            data = self._read_json()

            if path == "/api/analyze":
                prompt = build_analyze_prompt(data.get("initial_description", ""))
                response = run_gigacode(prompt)
                self._send_json({"ok": True, "response": response})
                return

            if path == "/api/generate":
                prompt = build_generate_prompt(data)
                response = run_gigacode(prompt)
                self._send_json({"ok": True, "response": response})
                return

            if path == "/api/review":
                prompt = build_review_prompt(data, data.get("generated_defect", ""))
                response = run_gigacode(prompt)
                self._send_json({"ok": True, "response": response})
                return

            self._send_json({"ok": False, "error": "Unknown endpoint"}, 404)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)}, 500)


def main():
    os.chdir(BASE_DIR)
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    url = f"http://{HOST}:{PORT}/index.html"
    print("AI Defect Reviewer & Investigator")
    print(f"URL: {url}")
    print("Остановить: Ctrl+C")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nОстановлено")


if __name__ == "__main__":
    main()
