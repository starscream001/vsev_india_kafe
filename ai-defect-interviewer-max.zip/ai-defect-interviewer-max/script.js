const $ = (id) => document.getElementById(id);
const loader = $('loader');

function setLoading(value) {
  loader.classList.toggle('hidden', !value);
}

function getData() {
  return {
    initial_description: $('initial_description').value.trim(),
    defect_type: $('defect_type').value.trim(),
    component: $('component').value.trim(),
    environment: $('environment').value.trim(),
    user_role: $('user_role').value.trim(),
    preconditions: $('preconditions').value.trim(),
    steps: $('steps').value.trim(),
    expected_result: $('expected_result').value.trim(),
    actual_result: $('actual_result').value.trim(),
    reproducibility: $('reproducibility').value.trim(),
    artifacts: $('artifacts').value.trim(),
    technical_details: $('technical_details').value.trim(),
    impact: $('impact').value.trim(),
    extra_context: $('extra_context').value.trim(),
  };
}

async function postJson(url, payload) {
  setLoading(true);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'Unknown error');
    return data.response;
  } finally {
    setLoading(false);
  }
}

$('analyzeBtn').addEventListener('click', async () => {
  const initial = $('initial_description').value.trim();
  if (!initial) {
    alert('Сначала напиши черновик дефекта');
    return;
  }
  $('analysisOutput').textContent = 'Запрашиваю анализ у GigaCode...';
  try {
    const response = await postJson('/api/analyze', { initial_description: initial });
    $('analysisOutput').textContent = response;
    $('analysisOutput').classList.remove('muted');
  } catch (e) {
    $('analysisOutput').textContent = 'Ошибка: ' + e.message;
  }
});

$('generateBtn').addEventListener('click', async () => {
  const payload = getData();
  if (!payload.initial_description) {
    alert('Нужно исходное описание дефекта');
    return;
  }
  $('defectOutput').textContent = 'Формирую дефект через GigaCode...';
  try {
    const response = await postJson('/api/generate', payload);
    $('defectOutput').textContent = response;
    $('defectOutput').classList.remove('muted');
  } catch (e) {
    $('defectOutput').textContent = 'Ошибка: ' + e.message;
  }
});

$('reviewBtn').addEventListener('click', async () => {
  const generated = $('defectOutput').textContent.trim();
  if (!generated || generated.startsWith('После генерации')) {
    alert('Сначала сформируй дефект');
    return;
  }
  const payload = getData();
  payload.generated_defect = generated;
  $('reviewOutput').textContent = 'Провожу AI Review через GigaCode...';
  try {
    const response = await postJson('/api/review', payload);
    $('reviewOutput').textContent = response;
    $('reviewOutput').classList.remove('muted');
  } catch (e) {
    $('reviewOutput').textContent = 'Ошибка: ' + e.message;
  }
});

document.querySelectorAll('.copy').forEach((button) => {
  button.addEventListener('click', async () => {
    const target = button.getAttribute('data-target');
    const text = $(target).textContent;
    await navigator.clipboard.writeText(text);
    const old = button.textContent;
    button.textContent = 'Скопировано';
    setTimeout(() => button.textContent = old, 1200);
  });
});
